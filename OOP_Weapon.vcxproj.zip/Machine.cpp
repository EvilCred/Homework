#include "Machine.h"

Machine::Machine()
{
	SetAmmo(100);
	SetMagazine(3);
	SetDammage(5);
	SetLenght(50);
}

void Machine::Shoot()
{
	if (GetAmmo() < 100) {
		cout << "Not enought ammo" << endl;
		Reload();
	}
	else {
		SetAmmo(GetAmmo() - 100);
		cout << "Bzzzzzz! Dammage: " << GetDammage() * 100 << endl;
	}
}

void Machine::Reload()
{
	if (GetMagazine() <= 0) {
		cout << "Not enought magazines" << endl;
	}
	else {
		SetAmmo(GetAmmo() + 100);
		cout << "Reloaded! Ammo: " << GetAmmo() << endl;

	}
}

void Machine::ShowWeapon()
{
	cout << "Name: Machine" << endl;
	cout << "Dammage (100 bullets): " << GetDammage()* 100 << endl;
	cout << "Ammo: " << GetAmmo() << endl;
	cout << "Magazine: " << GetMagazine() << endl;
	cout << "Lenght: " << GetLenght() << endl;
}
