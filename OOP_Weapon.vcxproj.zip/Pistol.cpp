#include "Pistol.h"

Pistol::Pistol()
{
	SetAmmo(50);
	SetMagazine(5);
	SetDammage(5);
	SetLenght(20);
}

void Pistol::Shoot()
{
	if (GetAmmo() <= 0) {
		cout << "Not enought ammo"<<endl;
		Reload();
	}
	else {
		SetAmmo(GetAmmo() - 1);
		cout << "Shoot! Dammage: " << GetDammage() << endl;
	}
}

void Pistol::Reload()
{
	if (GetMagazine() <= 0) {
		cout << "Not enought magazines" << endl;
	}
	else {
		SetAmmo(GetAmmo() + 10);
		cout << "Reloaded! Ammo: " << GetAmmo() << endl;
		
	}
}

void Pistol::ShowWeapon()
{
	cout<<"Name: Pistol"<<endl;
	cout << "Dammage: " << GetDammage() << endl;
	cout << "Ammo: " << GetAmmo() << endl;
	cout << "Magazine: " << GetMagazine() << endl;
	cout << "Lenght: " << GetLenght() << endl;

}
