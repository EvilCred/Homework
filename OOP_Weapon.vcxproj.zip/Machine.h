#include "Weapon.h"
#pragma once
class Machine : Weapon
{
public:
	Machine();
	void Shoot() override;
	void Reload() override;
	void ShowWeapon() override;

};



