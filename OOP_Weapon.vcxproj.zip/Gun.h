#include "Weapon.h"
#pragma once
class Gun : Weapon
{
public:
	Gun();
	void Shoot() override;
	void Reload() override;
	void ShowWeapon() override;

};