#include "Gun.h"

Gun::Gun()
{
	SetAmmo(1);
	SetMagazine(5);
	SetDammage(100);
	SetLenght(1200);
}

void Gun::Shoot()
{
	if (GetAmmo() <= 0) {
		cout << "Not enought ammo" << endl;
		Reload();
	}
	else {
		SetAmmo(GetAmmo() - 1);
		cout << "BaBaH! Dammage: " << GetDammage() << endl;
	}
}

void Gun::Reload()
{
	if (GetMagazine() <= 0) {
		cout << "Not enought magazines" << endl;
	}
	else {
		SetAmmo(GetAmmo() + 1);
		cout << "Reloaded! Ammo: " << GetAmmo() << endl;

	}
}

void Gun::ShowWeapon()
{
	cout << "Name: Gun" << endl;
	cout << "Dammage: " << GetDammage() << endl;
	cout << "Ammo: " << GetAmmo() << endl;
	cout << "Magazine: " << GetMagazine() << endl;
	cout << "Lenght: " << GetLenght() << endl;
}
