#include <iostream>
using namespace std;
#pragma once
class Weapon
{
public:
	virtual void Shoot() = 0;
	virtual void Reload() =0;
	virtual void ShowWeapon() = 0;
	int GetAmmo();
	int GetMagazine();
	int GetLenght();
	int GetDammage();
	void SetAmmo(int Ammo);
	void SetMagazine(int Magazine);
	void SetLenght(int Lenght);
	void SetDammage(int Dammage);
private:
	int Ammo;
	int Magazine;
	int Lenght;
	int Dammage;

};

