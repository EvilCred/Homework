#include "Weapon.h"

int Weapon::GetAmmo()
{
	return Ammo;
}

int Weapon::GetMagazine()
{
	return Magazine;
}

int Weapon::GetLenght()
{
	return Lenght;
}

int Weapon::GetDammage()
{
	return Dammage;
}

void Weapon::SetAmmo(int Ammo)
{
	this->Ammo = Ammo;
}

void Weapon::SetMagazine(int Magazine)
{
	this->Magazine = Magazine;
}

void Weapon::SetLenght(int Lenght)
{
	this->Lenght = Lenght;
}

void Weapon::SetDammage(int Dammage)
{
	this->Dammage = Dammage;
}
