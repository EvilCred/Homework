﻿#include <iostream>
#include"Pistol.h";
#include"Pistol.cpp";
#include"Gun.h";
#include"Gun.cpp";
#include"Machine.h";
#include"Machine.cpp";
#include"Knife.h";
#include"Knife.cpp";
#include"Chainsaw.h";
#include"Chainsaw.cpp";

int main()
{
    //Я не знаю почему ничего не работает, но код вроде правильный
    Pistol glock();
    glock().Shoot();
    glock().Reload();
    glock().ShowWeapon();
    cout << endl;
    Gun Pirate_Gun();
    Pirate_Gun().Shoot();
    Pirate_Gun().Reload();
    Pirate_Gun().ShowWeapon();
    cout << endl;
    Knife Kerambit();
    Kerambit().Shoot();
    Kerambit().Reload();
    Kerambit().ShowWeapon();
    cout << endl;
    Machine MiniGun();
    MiniGun().Shoot();
    MiniGun().Reload();
    MiniGun().ShowWeapon();
    cout << endl;
    Chainsaw Chainsaw123();
    Chainsaw123().Shoot();
    Chainsaw123().Reload();
    Chainsaw123().ShowWeapon();
    cout << endl;
}

