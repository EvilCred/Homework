#include "Chainsaw.h"

Chainsaw::Chainsaw()
{
	SetAmmo(100);
	SetMagazine(2);
	SetDammage(999);
	SetLenght(50);
}

void Chainsaw::Shoot()
{
	if (GetAmmo() < 50) {
		cout << "Not enought fuel" << endl;
		Reload();
	}
	else {
		SetAmmo(GetAmmo() - 50);
		cout << "VZNVZN! Dammage: " << GetDammage() << endl;
	}
}

void Chainsaw::Reload()
{
	if (GetMagazine() <= 0) {
		cout << "Not enought canistres" << endl;
	}
	else {
		SetAmmo(GetAmmo() + 10);
		cout << "Reloaded! Fuel: " << GetAmmo() << endl;

	}
}

void Chainsaw::ShowWeapon()
{
	cout << "Name: Chainsaw" << endl;
	cout << "Dammage: " << GetDammage() << endl;
	cout << "Fuel: " << GetAmmo() << endl;
	cout << "Canisters: " << GetMagazine() << endl;
	cout << "Lenght: " << GetLenght() << endl;
}
