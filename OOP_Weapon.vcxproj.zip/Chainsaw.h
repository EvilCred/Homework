#include "Weapon.h"
#pragma once
class Chainsaw : Weapon
{
public:
	Chainsaw();
	void Shoot() override;
	void Reload() override;
	void ShowWeapon() override;

};