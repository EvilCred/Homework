#include "Knife.h"

Knife::Knife()
{
	SetAmmo(1);
	SetMagazine(0);
	SetDammage(100);
	SetLenght(10);
}

void Knife::Shoot()
{
	cout << "Sharp! Dammage: " << GetDammage() << endl;
}

void Knife::Reload()
{
	cout << "You trying to reload knife? Really?" << endl;
}

void Knife::ShowWeapon()
{
	cout << "Name: Knife" << endl;
	cout << "Dammage: " << GetDammage() << endl;
	cout << "Ammo: No need" << endl;
	cout << "Magazine: No need" << endl;
	cout << "Lenght: " << GetLenght() << endl;
}
