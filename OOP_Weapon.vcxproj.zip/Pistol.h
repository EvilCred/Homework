#include "Weapon.h"
#pragma once
class Pistol : Weapon
{
public:
	Pistol();
	virtual void Shoot() override;
	virtual void Reload() override;
	virtual void ShowWeapon() override;

};

