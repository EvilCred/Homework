#include "Weapon.h"
#pragma once
class Knife : Weapon
{
public:
	Knife();
	void Shoot() override;
	void Reload() override;
	void ShowWeapon() override;

};

